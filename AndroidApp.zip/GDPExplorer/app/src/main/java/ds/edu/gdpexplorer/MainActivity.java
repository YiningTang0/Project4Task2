// Name: Yining Tang
// Andrew ID: yiningt

package ds.edu.gdpexplorer;

import android.graphics.Typeface;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.text.NumberFormat;
import java.util.Locale;
import android.os.AsyncTask;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    // Declare UI components
    private EditText countryInput;
    private TextView resultText, resultLabel, errorText;
    private ProgressBar progressBar;
    private Button fetchButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize view elements by ID
        countryInput = findViewById(R.id.countryInput);
        resultText = findViewById(R.id.resultText);
        resultLabel = findViewById(R.id.resultLabel);
        errorText = findViewById(R.id.errorText);
        progressBar = findViewById(R.id.progressBar);
        fetchButton = findViewById(R.id.fetchButton);

        // Set click listener on the fetch button
        fetchButton.setOnClickListener(v -> {
            String countryCode = countryInput.getText().toString().trim().toUpperCase();

            // Ensure the country code is exactly 2 characters (ISO standard)
            if (countryCode.length() != 2) {
                showError("Please enter a valid 2-letter country code");
            } else {
                // Execute the async task to fetch GDP data
                new FetchGDPTask().execute(countryCode);
            }
        });
    }

    // AsyncTask class to handle network request in the background
    private class FetchGDPTask extends AsyncTask<String, Void, String> {

        @Override
        protected void onPreExecute() {
            // Show progress bar, disable button, and clear previous results
            progressBar.setVisibility(View.VISIBLE);
            fetchButton.setEnabled(false);
            resultLabel.setVisibility(View.GONE);
            resultText.setText("");
            errorText.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... params) {
            String countryCode = params[0];

            // Construct the API URL using the country code
            String apiUrl = "https://legendary-space-computing-machine-gr6gj4g4xv5fwwgp-8080.app.github.dev/gdp/" + countryCode;

            Log.d("GDP_DEBUG", "Attempting to connect to: " + apiUrl);

            HttpURLConnection conn = null;
            BufferedReader reader = null;
            InputStream errorStream = null;

            try {
                // Open and configure the connection
                URL url = new URL(apiUrl);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(10000);

                // Set request headers
                conn.setRequestProperty("Accept", "application/json");
                conn.setRequestProperty("User-Agent", "GDPExplorer-App");

                Log.d("GDP_DEBUG", "Request Headers: " + conn.getRequestProperties());

                int responseCode = conn.getResponseCode();
                Log.d("GDP_DEBUG", "HTTP Response Code: " + responseCode);

                // If request is successful
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;

                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    Log.d("GDP_DEBUG", "Response (truncated): " +
                            (response.length() > 200 ? response.substring(0, 200) + "..." : response));

                    return response.toString();
                } else {
                    // Handle error response as required in the guideline
                    errorStream = conn.getErrorStream();
                    String errorResponse = "";

                    if (errorStream != null) {
                        reader = new BufferedReader(new InputStreamReader(errorStream));
                        StringBuilder errorBuilder = new StringBuilder();
                        String line;

                        while ((line = reader.readLine()) != null) {
                            errorBuilder.append(line);
                        }
                        errorResponse = errorBuilder.toString();
                        Log.e("GDP_ERROR", "Error Response: " + errorResponse);
                    }

                    return "Error: HTTP " + responseCode + (errorResponse.isEmpty() ? "" : " - " + errorResponse);
                }
            } catch (MalformedURLException e) {
                Log.e("GDP_ERROR", "Malformed URL: " + apiUrl, e);
                return "Error: Invalid URL - " + e.getMessage();
            } catch (SocketTimeoutException e) {
                Log.e("GDP_ERROR", "Connection timed out", e);
                return "Error: Connection timed out - check your network";
            } catch (IOException e) {
                Log.e("GDP_ERROR", "Network error", e);
                return "Error: Network error - " + e.getMessage();
            } finally {
                // Close resources to avoid memory leaks
                try {
                    if (reader != null) reader.close();
                    if (errorStream != null) errorStream.close();
                    if (conn != null) conn.disconnect();
                } catch (IOException e) {
                    Log.e("GDP_ERROR", "Error closing resources", e);
                }
            }
        }

        @Override
        protected void onPostExecute(String result) {
            // Hide progress bar and re-enable button
            progressBar.setVisibility(View.GONE);
            fetchButton.setEnabled(true);

            ScrollView scrollView = findViewById(R.id.scrollView);
            LinearLayout resultsContainer = findViewById(R.id.resultsContainer);
            TextView resultText = findViewById(R.id.resultText);

            // Handle error messages
            if (result.startsWith("Error:")) {
                showError(result);
                scrollView.setVisibility(View.GONE);
                resultText.setVisibility(View.GONE);
            } else {
                try {
                    // Parse JSON response
                    JSONArray jsonResponse = new JSONArray(result);
                    resultsContainer.removeAllViews();

                    if (jsonResponse.length() > 1) {
                        JSONArray dataArray = jsonResponse.getJSONArray(1);

                        if (dataArray.length() > 0) {
                            // Display scrollable results
                            resultText.setVisibility(View.GONE);
                            scrollView.setVisibility(View.VISIBLE);

                            // Create and style a header for the result list
                            TextView header = new TextView(MainActivity.this);
                            header.setText("GDP by Year:");
                            header.setTextSize(18);
                            header.setTypeface(null, Typeface.BOLD);
                            resultsContainer.addView(header);

                            // Loop through each GDP data point
                            // display it
                            for (int i = 0; i < dataArray.length(); i++) {
                                JSONObject yearData = dataArray.getJSONObject(i);
                                String year = yearData.optString("date", "N/A");
                                double gdpValue = yearData.optDouble("value", 0);

                                TextView yearView = new TextView(MainActivity.this);
                                yearView.setText(String.format("%s: %s",
                                        year,
                                        NumberFormat.getCurrencyInstance(Locale.US).format(gdpValue)));
                                yearView.setTextSize(16);
                                yearView.setPadding(0, 8, 0, 8);

                                resultsContainer.addView(yearView);
                            }
                        } else {
                            showError("No GDP data available for this country");
                        }
                    } else {
                        showError("Invalid API response format");
                    }
                } catch (JSONException e) {
                    showError("Error parsing data: " + e.getMessage());
                }
            }
        }
    }

    // Display error message on screen and as a Toast
    private void showError(String message) {
        errorText.setText(message);
        errorText.setVisibility(View.VISIBLE);
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}

// ai appendix: deepseek is used for brainstorming and syntax, formatting adjusts and comments grammar check--%>
