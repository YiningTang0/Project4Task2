//Name: Yining Tang
//Andrew ID: yiningt
package ds.project4task2;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.bson.Document;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Date;

@WebServlet("/gdp/*")
public class GDPWebService extends HttpServlet {
    private MongoClient mongoClient;

    //This method is called once when the servlet is initialized.
    //creates a connection to the MongoDB Atlas database.
    @Override
    public void init() {
        String uri = "mongodb+srv://yiningt:Ning200625@cluster0.ij87b.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
        this.mongoClient = MongoClients.create(uri); // Create MongoDB client
    }

    //Handles HTTP GET requests.
    // Extracts the country code from the URL,
    // fetches GDP data from the World Bank API, stores it in MongoDB, and returns the JSON response.
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        // Get the country code from the URL path (/gdp/US → "US")
        String countryCode = req.getPathInfo().substring(1);

        //  Fetch GDP data from World Bank API
        String apiResponse = fetchFromWorldBank(countryCode);

        //  Store the data in MongoDB for logging/tracking
        storeInMongoDB(countryCode, apiResponse);

        //  Return the JSON response to the client (e.g., Android app)
        resp.setContentType("application/json");
        resp.getWriter().write(apiResponse);
    }

    // Fetches GDP data for a given country from the World Bank API.
    private String fetchFromWorldBank(String countryCode) throws IOException {
        // Construct the API URL for the specified country
        String apiUrl = "https://api.worldbank.org/v2/country/" + countryCode + "/indicator/NY.GDP.MKTP.CD?format=json";
        URL url = new URL(apiUrl);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        // Read the API response
        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }

        return response.toString(); // Return the raw JSON
    }

    // Stores the fetched GDP data into MongoDB for record keeping.
    private void storeInMongoDB(String countryCode, String data) {
        // Connect to the database and collection
        MongoDatabase db = mongoClient.getDatabase("gdp_data");
        MongoCollection<Document> collection = db.getCollection("logs");

        // Create a document with country code, data, and timestamp
        Document logEntry = new Document()
                .append("country", countryCode)
                .append("data", data)
                .append("timestamp", new Date());

        // Insert the document into the collection
        collection.insertOne(logEntry);
    }
}

//<%--//ai appendix: deepseek and chatgpt are used for brainstorming and syntax, comments grammar and sentence flow--%>