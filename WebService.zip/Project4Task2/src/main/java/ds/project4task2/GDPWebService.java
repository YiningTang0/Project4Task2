// Name: Yining Tang
// Andrew ID: yiningt

package ds.project4task2;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.bson.Document;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Date;

@WebServlet("/gdp/*")  // Servlet URL mapping, e.g., /gdp/US
public class GDPWebService extends HttpServlet {
    private MongoClient mongoClient;
    private static final String WORLD_BANK_API = "https://api.worldbank.org/v2/country/%s/indicator/NY.GDP.MKTP.CD?format=json";

    @Override
    public void init() {
        // Initialize MongoDB client using Atlas URI
        String uri = "mongodb+srv://yiningt:Ning200625@cluster0.ij87b.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
        this.mongoClient = MongoClients.create(uri);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        // Extract country code from URL (e.g., /gdp/US → "US")
        String countryCode = req.getPathInfo().substring(1);

        // Fetch GDP data from World Bank API
        String apiResponse = fetchFromWorldBank(countryCode);

        //Create comprehensive log document with required fields
        Document logEntry = createLogEntry(req, countryCode, apiResponse);

        // Store raw API data and request log in MongoDB
        storeInMongoDB(logEntry);

        // Send API response back to Android app as JSON
        resp.setContentType("application/json");
        resp.getWriter().write(apiResponse);
    }

    // Helper method to retrieve GDP data for a country from the World Bank API
    private String fetchFromWorldBank(String countryCode) throws IOException {
        // Construct API URL for GDP indicator (NY.GDP.MKTP.CD)
        String apiUrl = "https://api.worldbank.org/v2/country/" + countryCode + "/indicator/NY.GDP.MKTP.CD?format=json";
        URL url = new URL(apiUrl);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        // Read the API response using BufferedReader
        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder response = new StringBuilder();
        String line;

        // Append each line to the response
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }

        return response.toString();  // Return JSON as string
    }

    private Document createLogEntry(HttpServletRequest req, String countryCode, String apiResponse) {
        return new Document()
                .append("country", countryCode)                     // 1. Requested country
                .append("userAgent", req.getHeader("User-Agent"))   // 2. Android device info
                .append("clientIP", req.getRemoteAddr())            // 3. Client IP address
                .append("apiEndpoint", WORLD_BANK_API)              // 4. Which API was called
                .append("requestMethod", req.getMethod())           // 5. HTTP method (GET)
                .append("responseSize", apiResponse.length())       // 6. Response size in bytes
                .append("serverProcessingTime", System.currentTimeMillis() - req.getSession().getCreationTime()) // 7. Processing time
                .append("timestamp", new Date())              // 8. Request timestamp
                .append("response", apiResponse);  // 9.Response data
    }

    // Helper method to store fetched data in MongoDB
    private void storeInMongoDB(Document logEntry) {
        // Access the database "gdp_data" and the collection "logs"
        MongoDatabase db = mongoClient.getDatabase("gdp_data");
        MongoCollection<Document> collection = db.getCollection("logs");

        // Insert the document into MongoDB
        collection.insertOne(logEntry);
    }
}
// ai appendix: deepseek is used for brainstorming and syntax, formatting adjusts and comments grammar check
