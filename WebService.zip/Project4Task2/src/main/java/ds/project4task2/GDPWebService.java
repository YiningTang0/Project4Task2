// Name: Yining Tang
// Andrew ID: yiningt

package ds.project4task2;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.bson.Document;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Date;

//A servlet that handles GDP requests and logs analytics to MongoDB.

@WebServlet("/gdp/*")
public class GDPWebService extends HttpServlet {
    private MongoClient mongoClient;

    //Initialize MongoDB client during servlet startup.
    @Override
    public void init() {
        // MongoDB Atlas connection URI
        String uri = "mongodb+srv://yiningt:Ning200625@cluster0.ij87b.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
        this.mongoClient = MongoClients.create(uri);
    }

    //Handles GET requests from mobile clients.

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        // Extract country code from the request URI
        String countryCode = req.getPathInfo().substring(1);

        // Capture client request metadata
        String clientIP = req.getRemoteAddr();                      // IP address of the client
        String userAgent = req.getHeader("User-Agent");            // User agent string (phone model info)
        Date requestTime = new Date();                             // Timestamp when request is received

        // Construct the World Bank API URL
        String apiUrl = "https://api.worldbank.org/v2/country/" + countryCode + "/indicator/NY.GDP.MKTP.CD?format=json";

        // Send request to 3rd party API and measure latency
        long apiStart = System.currentTimeMillis();
        String apiResponse = fetchFromWorldBank(apiUrl);
        long apiEnd = System.currentTimeMillis();
        long apiLatency = apiEnd - apiStart;

        // Log relevant analytics data to MongoDB
        storeInMongoDB(countryCode, apiUrl, apiResponse, clientIP, userAgent, requestTime, apiLatency);

        // Send the API response back to the mobile client
        resp.setContentType("application/json");
        resp.getWriter().write(apiResponse);
    }

    //Makes a GET request to the World Bank API.

    private String fetchFromWorldBank(String apiUrl) throws IOException {
        URL url = new URL(apiUrl);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder response = new StringBuilder();
        String line;

        // Read the full JSON response
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }

        return response.toString();
    }

    //Logs request/response details to MongoDB for dashboard tracking.
    private void storeInMongoDB(String countryCode, String apiUrl, String apiResponse, String clientIP, String userAgent, Date requestTime, long apiLatency) {
        MongoDatabase db = mongoClient.getDatabase("gdp_data");
        MongoCollection<Document> collection = db.getCollection("logs");

        // Create a new document to log all relevant fields
        Document logEntry = new Document()
                .append("country", countryCode) //country code
                .append("api_url", apiUrl) //Full API request URL
                .append("api_latency_ms", apiLatency) //Time taken to get API response in ms
                .append("response", apiResponse)//Response JSON from the World Bank API
                .append("client_ip", clientIP)//IP address of client
                .append("user_agent", userAgent)//Phone model/user agent
                .append("timestamp", requestTime);//Timestamp when request was received

        collection.insertOne(logEntry); // Insert into MongoDB
    }
}

//ai appendix: chagpt and deepseek are used for brainstorming, syntax, grammar, sentence flow, debugging
